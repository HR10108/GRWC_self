package no.nordicsemi.android.nrftoolbox;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.Toast;

import java.lang.reflect.Field;

import no.nordicsemi.android.nrftoolbox.adapter.BaseFragmentAdapter;
import no.nordicsemi.android.nrftoolbox.calibration.CalibrationActivity;
import no.nordicsemi.android.nrftoolbox.gesture.GestureActivity;
import no.nordicsemi.android.nrftoolbox.heartrate.HRSActivity;
import no.nordicsemi.android.nrftoolbox.threedimension.ThreeDimensionActivity;
import no.nordicsemi.android.nrftoolbox.uart.UARTActivity;


public class HomeActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {


    private ViewPager mViewPager;
    private BottomNavigationView mBottomNavigationView;

    private BaseFragmentAdapter<Fragment> mPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initView();
    }

    private void initView() {
        mViewPager = (ViewPager) findViewById(R.id.vp_home_pager);
        mBottomNavigationView = (BottomNavigationView) findViewById(R.id.bv_home_navigation);
        disableShiftMode(mBottomNavigationView);
        // 不使用图标默认变色
        mBottomNavigationView.setItemIconTintList(null);
        //设置底部按钮点击事件
        mBottomNavigationView.setOnNavigationItemSelectedListener(this);
        initData();

    }

    public static void disableShiftMode(BottomNavigationView navigationView) {

        BottomNavigationMenuView menuView = (BottomNavigationMenuView) navigationView.getChildAt(0);

        try {

            Field shiftingMode = menuView.getClass().getDeclaredField("mShiftingMode");

            shiftingMode.setAccessible(true);

            shiftingMode.setBoolean(menuView, false);

            shiftingMode.setAccessible(false);

            for (int i = 0; i < menuView.getChildCount(); i++) {

                BottomNavigationItemView itemView = (BottomNavigationItemView) menuView.getChildAt(i);

                itemView.setShiftingMode(false);

                itemView.setChecked(itemView.getItemData().isChecked());

            }

        } catch (NoSuchFieldException | IllegalAccessException e) {

            e.printStackTrace();

        }

    }

    protected void initData() {
        //给viewpager 添加fragment,对应主页的三个页面
        mPagerAdapter = new BaseFragmentAdapter<>(this);
        mPagerAdapter.addFragment(ThreeDimensionActivity.newInstance());
        mPagerAdapter.addFragment(CalibrationActivity.newInstance());
        mPagerAdapter.addFragment(GestureActivity.newInstance());
        mPagerAdapter.addFragment(UARTActivity.newInstance());
        mPagerAdapter.addFragment(HRSActivity.newInstance());

        // 设置成懒加载模式
        mPagerAdapter.setLazyMode(true);
        mViewPager.setAdapter(mPagerAdapter);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.menu_3d:
                mViewPager.setCurrentItem(0);
                return true;
            case R.id.menu_cili:

                mViewPager.setCurrentItem(1);
                return true;
            case R.id.menu_shoushi:

                mViewPager.setCurrentItem(2);
                return true;
            case R.id.menu_content:

                mViewPager.setCurrentItem(3);
                return true;
            case R.id.menu_rate:

                mViewPager.setCurrentItem(4);
                return true;
            default:
                break;
        }
        return false;
    }


    @Override
    protected void onDestroy() {
        mViewPager.setAdapter(null);
        mBottomNavigationView.setOnNavigationItemSelectedListener(null);
        super.onDestroy();
    }
}