package no.nordicsemi.android.nrftoolbox.uart;

public interface UARTInterface {
	void send(final String text);
}
