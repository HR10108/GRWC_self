package no.nordicsemi.android.nrftoolbox.heartrate;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import no.nordicsemi.android.nrftoolbox.HomeActivity;
import no.nordicsemi.android.nrftoolbox.R;

public class HRSActivity extends Fragment {
    Dialog alertDialog;
    private View inflate;

    public static HRSActivity newInstance() {

        Bundle args = new Bundle();

        HRSActivity fragment = new HRSActivity();
        fragment.setArguments(args);
        return fragment;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        inflate = inflater.inflate(R.layout.activity_hrs, container, false);
        initView(savedInstanceState);
        return inflate;
    }

    protected void initView(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Toolbar toolbar = (Toolbar) inflate.findViewById(R.id.toolbar_actionbar);
        HomeActivity activity = (HomeActivity) getActivity();
        activity.setSupportActionBar(toolbar);
        activity.getSupportActionBar().setDisplayShowTitleEnabled(false);  //设置返回键操作
        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        final String text = new String("该页显示二维心率曲线");
        alertDialog = new AlertDialog.Builder(getContext()).setTitle(R.string.about_title).setMessage(text).setPositiveButton(R.string.ok, null).create();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.help, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_about:
                alertDialog.show();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

}
